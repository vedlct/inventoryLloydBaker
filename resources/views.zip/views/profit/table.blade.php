<div class="table table-responsive">
    <table id="datatable" class="table table-bordered">
        <thead>
        <tr>
            <th style="font-weight: bold">BRAND</th>
            <th style="font-weight: bold">CATEGORY</th>
            <th style="font-weight: bold">NAME</th>
            <th style="font-weight: bold">FACTORY CODE</th>
            <th style="font-weight: bold">COLOUR</th>
            <th style="font-weight: bold">EAN 13 BARCODES</th>
            <th style="font-weight: bold">CP</th>
            <th style="font-weight: bold">SP</th>
            <th style="font-weight: bold">RRP</th>
            <th style="font-weight: bold">QTY IN WAREHOUSE</th>
            <th style="font-weight: bold">shop-1</th>
            <th style="font-weight: bold">shop-2</th>
            <th style="font-weight: bold">shop-3</th>


        </tr>
        </thead>


        <tbody>
        <tr>
            <td>PC</td>

            <td>LADIES</td>

            <td>THE AURORA PC6148</td>
            <td>01-61481BQ</td>
            <td>TAUPE BROWN 1BQ</td>
            <td></td>
            <td></td>
            <td>£69.99</td>
            <td>£230.00</td>
            <td>7</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>


        </tr>
        <tr>
            <td>PC</td>

            <td>LADIES</td>

            <td>THE AURORA PC6148</td>
            <td>01-61484A</td>
            <td>NAVY</td>
            <td></td>
            <td></td>
            <td>£69.99</td>
            <td>£230.00</td>
            <td>7</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>LADIES</td>

            <td>THE MARIELLE KEYRING PC3151</td>
            <td>02-3151BLK</td>
            <td>BLACK</td>
            <td>5060615064915</td>
            <td></td>
            <td>£12.99</td>
            <td>£34.99</td>
            <td>4</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>THE AURORA PC6148</td>
            <td>01-61481BQ</td>
            <td>TAUPE BROWN 1BQ</td>
            <td></td>
            <td></td>
            <td>£69.99</td>
            <td>£230.00</td>
            <td>10</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>LB6421X</td>
            <td>3-6421XTAN</td>
            <td>TAUPE BROWN 1BQ</td>
            <td>5060615065394</td>
            <td></td>
            <td>£69.99</td>
            <td>£230.00</td>
            <td>7</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>THE AURORA PC6148</td>
            <td>3-6421XTAN</td>
            <td>A.Tan NDM</td>
            <td></td>
            <td></td>
            <td>£79.99</td>
            <td>£225.00</td>
            <td>25</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>

        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>THE ETICHETTA SIGNAGE  PC5161</td>
            <td>3-5161P32D</td>
            <td>Rose Pink 32DA</td>
            <td>5060615066018</td>
            <td></td>
            <td>£39.99</td>
            <td>£150.00</td>
            <td>14</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>LB5203</td>
            <td>3-5203BL</td>
            <td>Blue VT Flat</td>
            <td>5060615065462</td>
            <td></td>
            <td>£49.99</td>
            <td>£200.00</td>
            <td>14</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>LB5754</td>
            <td>3-5754OW</td>
            <td>Off White NDM</td>
            <td>5060615065653</td>
            <td></td>
            <td>£89.99</td>
            <td>£225.00</td>
            <td>80</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>LADIES</td>

            <td>LB5860</td>
            <td>3-5865AXBK</td>
            <td>Black RJ Croc</td>
            <td>5060615065660</td>
            <td></td>
            <td>£59.99</td>
            <td>£175.00</td>
            <td>25</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>LADIES</td>

            <td>LB5873</td>
            <td>3-5873BK</td>
            <td>Black Floater</td>
            <td>5060615065707</td>
            <td></td>
            <td>£79.99</td>
            <td>£179.00</td>
            <td>58</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>LADIES</td>

            <td>LB5876AY</td>
            <td>3-5876AYTAN</td>
            <td>A.Tan NDM</td>
            <td>5060615065721</td>
            <td></td>
            <td>£59.99</td>
            <td>£175.00</td>
            <td>14</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>LB6103A</td>
            <td>3-6103A931D</td>
            <td>Pink 31DC NDM</td>
            <td>5060615065844</td>
            <td></td>
            <td>£79.99</td>
            <td>£175.00</td>
            <td>24</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>LB6115A</td>
            <td>3-6115AB40</td>
            <td>Blue 40RA NDM</td>
            <td></td>
            <td></td>
            <td>£79.99</td>
            <td>£175.00</td>
            <td>17</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>LB6115A</td>
            <td>3-6115AB1Y</td>
            <td>Brown 1Y NDM</td>
            <td>5060615065875</td>
            <td></td>
            <td>£79.99</td>
            <td>£175.00</td>
            <td>17</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>

        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>LB6256AX</td>
            <td>3-6256AXG103</td>
            <td>Gunmetal 103Y RJ Metalic Foil</td>
            <td>5060615065882</td>
            <td></td>
            <td>£49.99</td>
            <td>£200.00</td>
            <td>27</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>LB6517</td>
            <td>3-6514TAN</td>
            <td>A.Tan NDM</td>
            <td></td>
            <td></td>
            <td>£79.99</td>
            <td>£175.00</td>
            <td>35</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>LB6517</td>
            <td>3-6517B41A</td>
            <td>Blue 41A NDM</td>
            <td></td>
            <td></td>
            <td>£79.99</td>
            <td>£175.00</td>
            <td>14</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>LB6577X</td>
            <td>3-6577XBRN</td>
            <td>Brown NDM</td>
            <td>5060615065905</td>
            <td></td>
            <td>£79.99</td>
            <td>£225.00</td>
            <td>47</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>
        <tr>
            <td>PC</td>

            <td>F- SLG</td>

            <td>LB1232</td>
            <td>01-1232BLK</td>
            <td>BLACK</td>
            <td>5060615064342</td>
            <td></td>
            <td>£79.99</td>
            <td>£125.00</td>
            <td>7</td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>
            <td>
                <table class="table table-bordered">
                    <thead>
                    <th>QTY SOLD</th>
                    <th>profit</th>
                    </thead>
                    <tbody>
                    <td>7</td>
                    <td>£69.99</td>
                    </tbody>
                </table>
            </td>

        </tr>

        </tbody>
    </table>
</div>