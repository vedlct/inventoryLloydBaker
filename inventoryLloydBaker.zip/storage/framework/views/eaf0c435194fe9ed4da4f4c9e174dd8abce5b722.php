<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <div class="row">


            </div>

        </div>
        <div class="card-body">
            <div class="row">
                <div class="form-group col-md-12">
                    <label>Excel File</label>
                    <input type="file" class="form-control" placeholder="insert excel report">
                </div>
                <div class="form-group col-md-12">
                    <button class="btn btn-sm btn-success pull-right">Submit</button>
                </div>



                <div class="form-group col-md-12">
                    <button class="btn btn-sm btn-success pull-right">Submit</button>

                </div>



            </div>

        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>