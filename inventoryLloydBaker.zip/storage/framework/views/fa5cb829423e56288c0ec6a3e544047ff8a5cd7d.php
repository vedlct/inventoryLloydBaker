<!-- MENU Start -->
<div class="navbar-custom">
    <div class="container-fluid">
        <div id="navigation">
            <!-- Navigation Menu-->
            <ul class="navigation-menu">

                <li class="has-submenu">
                    <a href="<?php echo e(route('mainsreen')); ?>"><i class="ti-home"></i>MAIN SCREEN</a>
                </li>

                <li class="has-submenu">
                    <a href=""><i class="ti-light-bulb"></i>GOODS IN</a>
                    <ul class="submenu">
                        <li><a href="<?php echo e(route('goods-in.add')); ?>">Add Individual Goods </a></li>
                        <li><a href="<?php echo e(route('goods-in.bulk')); ?>">Add Bulk Goods </a></li>
                        <li><a href="<?php echo e(route('goods-in.show')); ?>">Show Goods </a></li>



                    </ul>
                </li>

                <li class="has-submenu">
                    <a href=""><i class="ti-light-bulb"></i>STOCK TRANSFER</a>
                    <ul class="submenu">
                        <li> <a href="<?php echo e(route('stocktransfer.show')); ?>">Stock Transfer</a></li>
                        <li><a href="<?php echo e(route('goods-in.bulk')); ?>">Stock Transfer in Bulk</a></li>
                    </ul>

                </li>


                <li class="has-submenu">
                    <a href=""><i class="ti-bookmark-alt"></i>STOCK OUT</a>
                    <ul class="submenu">
                        <li><a href="<?php echo e(route('goods-in.bulk')); ?>">Import Sales</a></li>
                        <li><a href="<?php echo e(route('stock.out')); ?>">Show Sales</a></li>
                    </ul>
                </li>

                <li class="has-submenu">
                    <a href=""><i class="ti-bookmark-alt"></i>Reporting</a>
                    <ul class="submenu">
                        <li class="has-submenu"><a href="">Profit</a>
                            <ul class="submenu">
                                <li><a href="<?php echo e(route('profit.profitCalculation')); ?>">Profit Calculation</a></li>
                                <li><a href="<?php echo e(route('profit.mostProfitableProduct')); ?>">Most Profitable Product</a></li>
                            </ul>
                        </li>
                        <li><a href="<?php echo e(route('report.sellData')); ?>">Stock Valuation</a></li>

                    </ul>
                </li>

                <li class="has-submenu">
                    <a href=""><i class="ti-bookmark-alt"></i>Settings</a>
                    <ul class="submenu">
                        <li><a href="<?php echo e(route('settings.productCategory')); ?>">Product Category</a></li>
                        <li><a href="<?php echo e(route('settings.location')); ?>">Location</a></li>
                        <li><a href="<?php echo e(route('settings.color')); ?>">Color</a></li>
                        <li><a href="<?php echo e(route('settings.size')); ?>">Size</a></li>
                        <li><a href="<?php echo e(route('settings.brand')); ?>">Brand</a></li>
                        <li><a href="<?php echo e(route('settings.style')); ?>">Style</a></li>
                        <li><a href="<?php echo e(route('settings.user')); ?>">User</a></li>

                    </ul>
                </li>

            </ul>
            <!-- End navigation menu -->
        </div> <!-- end #navigation -->
    </div> <!-- end container -->
</div> <!-- end navbar-custom -->