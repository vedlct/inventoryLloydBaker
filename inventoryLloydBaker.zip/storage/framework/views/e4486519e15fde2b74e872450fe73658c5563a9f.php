<?php echo $__env->make('layouts/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

<!-- Loader -->


<!-- Navigation Bar-->
<header id="topnav">
    <div class="topbar-main">
        <div class="container-fluid">

            <!-- Logo container-->
            <div class="logo">
                <!-- Text Logo -->
                <!--<a href="index.html" class="logo">-->
                <!--Upcube-->
                <!--</a>-->
                <!-- Image Logo -->
                <a href="<?php echo e(route('main')); ?>" class="logo">
                    <img src="assets/images/logo-sm.png" alt="" height="22" class="logo-small">
                    
                    <h3>WareHouse Stock Control</h3>
<!--                    <img src="assets/images/logo.png" alt="" height="24" class="logo-large">-->
                </a>

            </div>
            <!-- End Logo container-->


            <div class="menu-extras topbar-custom">

                <!-- Search input -->
                
                    
                        
                        
                            
                        
                    
                

                <ul class="list-inline float-right mb-0">
                    <!-- Search -->
                    
                        
                            
                        
                    
                    <!-- Messages-->
                    
                        
                           
                            
                            
                        
                        
                            
                            
                                
                            

                            
                            
                                
                                
                            

                            
                            
                                
                                
                            

                            
                            
                                
                                
                            

                            
                            
                                
                            

                        
                    
                    <!-- notification-->
                    
                        
                           
                            
                            
                        
                        
                            
                            
                                
                            

                            
                            
                                
                                
                            

                            
                            
                                
                                
                            

                            
                            
                                
                                
                            

                            
                            
                                
                            

                        
                    
                    <!-- User-->
                    <li class="list-inline-item dropdown notification-list">
                        <a class="nav-link dropdown-toggle arrow-none waves-effect nav-user" data-toggle="dropdown" href="#" role="button"
                           aria-haspopup="false" aria-expanded="false">
                            <img src="assets/images/users/avatar-1.jpg" alt="user" class="rounded-circle">
                        </a>
                        <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                            <a class="dropdown-item" href="#"><i class="dripicons-user text-muted"></i> Profile</a>
                            
                            <a class="dropdown-item" href="#"><i class="dripicons-gear text-muted"></i>Change Password</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('/')); ?>"><i class="dripicons-exit text-muted"></i> Logout</a>
                        </div>
                    </li>
                    <li class="menu-item list-inline-item">
                        <!-- Mobile menu toggle-->
                        <a class="navbar-toggle nav-link">
                            <div class="lines">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </a>
                        <!-- End mobile menu toggle-->
                    </li>

                </ul>
            </div>
            <!-- end menu-extras -->

            <div class="clearfix"></div>

        </div> <!-- end container -->
    </div>
    <!-- end topbar-main -->

    <?php echo $__env->make('layouts/navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</header>
<!-- End Navigation Bar-->


<div class="wrapper">
    <div class="container-fluid">

        <?php echo $__env->yieldContent('content'); ?>

    </div> <!-- end container -->
</div>
<!-- end wrapper -->

<?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>