<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="form-group col-md-6">
                    <label>Import The File</label>
                    <input type="file" class="form-control" placeholder="product name">
                </div>
                <div class="form-group col-md-12">
                    <button class="btn btn-sm btn-success ">Submit</button>
                </div>


            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>